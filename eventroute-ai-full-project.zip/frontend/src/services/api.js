/**
 * API Service for EventRoute AI
 * Connects to FastAPI backend if available, or gracefully falls back to client-side engine.
 */

import { INITIAL_EVENTS, STUDENT_PROFILE, EXAM_CALENDAR } from "../data/initialEvents";
import { rankEvents, calculateSkillGap, generateClientODLetter, processClientAssistant } from "./aiEngine";

let backendAvailable = null;
let lastHealthCheck = 0;
const HEALTH_CACHE_MS = 6000;

export async function checkBackendHealth(force = false) {
  const now = Date.now();
  if (!force && backendAvailable !== null && (now - lastHealthCheck < HEALTH_CACHE_MS)) {
    return backendAvailable;
  }
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    const res = await fetch("/api/health", { 
      method: "GET", 
      headers: { "Accept": "application/json" },
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      backendAvailable = true;
      lastHealthCheck = now;
      return true;
    }
  } catch (err) {
    backendAvailable = false;
  }
  backendAvailable = false;
  lastHealthCheck = now;
  return false;
}

export async function fetchOpportunities(feedbackWeights = {}, downvotedEvents = new Set(), upvotedEvents = new Set()) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      const res = await fetch("/api/events");
      if (res.ok) {
        const data = await res.json();
        return data.events;
      }
    } catch (e) {
      console.warn("Backend error, falling back to local engine", e);
    }
  }

  // Fallback to client-side ranking
  return rankEvents(INITIAL_EVENTS, STUDENT_PROFILE, EXAM_CALENDAR, feedbackWeights, downvotedEvents, upvotedEvents);
}

export async function sendFeedback(eventId, action, reasonTag) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      const res = await fetch("/api/events/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ event_id: eventId, action, reason_tag: reasonTag })
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn("Backend feedback error", e);
    }
  }
  return { status: "local_success", event_id: eventId, action, reason_tag: reasonTag };
}

export async function fetchSkillGap(eventId, eventObj) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      const res = await fetch(`/api/events/${eventId}/skill-gap`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn("Backend skill gap error", e);
    }
  }
  return calculateSkillGap(eventObj || INITIAL_EVENTS.find(e => e.id === eventId));
}

export async function requestODLetter(eventId, collegeKey, eventObj) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      const res = await fetch("/api/od-letter/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ event_id: eventId, college_key: collegeKey })
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn("Backend OD letter error", e);
    }
  }
  return generateClientODLetter(eventObj || INITIAL_EVENTS.find(e => e.id === eventId), collegeKey);
}

export async function askAssistant(message, events) {
  try {
    const isUp = await checkBackendHealth();
    if (isUp) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);
        const res = await fetch("/api/assistant/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message, query: message, prompt: message }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (res.ok) {
          const data = await res.json();
          if (data && data.reply) {
            return data;
          }
        }
      } catch (e) {
        console.warn("Backend assistant error, falling back to client AI:", e);
        backendAvailable = false;
      }
    }
  } catch (err) {
    console.warn("Health check exception in askAssistant:", err);
  }
  return processClientAssistant(message, events, STUDENT_PROFILE);
}

export async function syncShortlistAdd(event) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      await fetch("/api/shortlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(event)
      });
    } catch (e) {
      console.warn("Backend shortlist add error", e);
    }
  }
}

export async function syncShortlistRemove(eventId) {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      await fetch(`/api/shortlist/${eventId}`, {
        method: "DELETE"
      });
    } catch (e) {
      console.warn("Backend shortlist remove error", e);
    }
  }
}

export async function syncShortlistGet() {
  const isUp = await checkBackendHealth();
  if (isUp) {
    try {
      const res = await fetch("/api/shortlist");
      if (res.ok) {
        const data = await res.json();
        return data.shortlist || [];
      }
    } catch (e) {
      console.warn("Backend shortlist get error", e);
    }
  }
  return [];
}
